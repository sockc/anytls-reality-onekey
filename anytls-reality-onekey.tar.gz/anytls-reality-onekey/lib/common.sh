#!/usr/bin/env bash

color() {
  local code="$1" text="$2"
  printf '\033[%sm%s\033[0m\n' "$code" "$text"
}

ok() { color '32' "[OK] $*"; }
warn() { color '33' "[WARN] $*"; }
err() { color '31' "[ERR] $*"; }
info() { color '36' "[INFO] $*"; }
die() { err "$*"; exit 1; }

need_root() {
  if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
    die "请使用 root 运行。"
  fi
}

press_enter() {
  read -r -p "按回车继续..." _
}

prompt_with_default() {
  local message="$1" default_value="$2" input
  read -r -p "${message} [默认 ${default_value}]: " input
  printf '%s' "${input:-$default_value}"
}

prompt_required() {
  local message="$1" input
  while true; do
    read -r -p "${message}: " input
    [[ -n "$input" ]] && { printf '%s' "$input"; return 0; }
    warn "不能为空。"
  done
}

random_alnum() {
  local len="$1"
  tr -dc 'A-Za-z0-9' </dev/urandom | head -c "$len"
}

random_hex() {
  local bytes="$1"
  openssl rand -hex "$bytes"
}

prompt_or_random() {
  local message="$1" len="$2" input generated
  read -r -p "${message}: " input
  if [[ -n "$input" ]]; then
    printf '%s' "$input"
  else
    generated="$(random_alnum "$len")"
    printf '%s' "$generated"
  fi
}

port_in_use() {
  local port="$1"
  ss -lntup 2>/dev/null | awk '{print $5}' | grep -Eq "(^|[\]:])${port}$"
}

prompt_port() {
  local message="$1" default_port="$2" port
  while true; do
    port="$(prompt_with_default "$message" "$default_port")"
    [[ "$port" =~ ^[0-9]+$ ]] || { warn "端口必须是数字。"; continue; }
    (( port >= 1 && port <= 65535 )) || { warn "端口范围必须在 1-65535。"; continue; }
    if port_in_use "$port"; then
      warn "端口 ${port} 已被占用，请换一个。"
      continue
    fi
    printf '%s' "$port"
    return 0
  done
}

prompt_short_id() {
  local message="$1" input
  read -r -p "${message}: " input
  if [[ -z "$input" ]]; then
    printf '%s' "$(random_hex 4)"
    return 0
  fi
  if [[ ! "$input" =~ ^[0-9a-fA-F]{2,16}$ ]] || (( ${#input} % 2 != 0 )); then
    die "short_id 必须是 2-16 位十六进制字符，且长度必须为偶数。"
  fi
  printf '%s' "$input"
}

ensure_basic_tools() {
  local missing=()
  for bin in systemctl ss openssl awk sed grep; do
    command -v "$bin" >/dev/null 2>&1 || missing+=("$bin")
  done
  if ((${#missing[@]} > 0)); then
    die "缺少必要命令: ${missing[*]}"
  fi
}

ensure_supported_os() {
  [[ -r /etc/os-release ]] || die "无法识别系统。"
  . /etc/os-release
  case "${ID:-}" in
    debian|ubuntu) ;;
    *) die "当前仅支持 Debian / Ubuntu。" ;;
  esac
}

backup_existing_singbox_config() {
  mkdir -p /etc/sing-box
  if [[ -f /etc/sing-box/config.json ]]; then
    cp -f /etc/sing-box/config.json /etc/sing-box/config.json.xnode.bak
  fi
}

install_server_config_to_singbox() {
  local src="$1"
  mkdir -p /etc/sing-box
  cp -f "$src" /etc/sing-box/config.json
}

validate_singbox_config() {
  sing-box check -c /etc/sing-box/config.json >/dev/null
}

require_service_exists() {
  local service="$1"
  command -v systemctl >/dev/null 2>&1 || die "当前系统没有 systemctl。"
  systemctl list-unit-files | grep -q "^${service}\.service" || die "未检测到 ${service} 服务。"
}

enable_and_restart_service() {
  local service="$1"
  systemctl daemon-reload
  systemctl enable "$service" >/dev/null 2>&1 || true
  systemctl restart "$service"
}

fetch_text() {
  local url="$1"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$url"
  elif command -v wget >/dev/null 2>&1; then
    wget -qO- "$url"
  else
    return 1
  fi
}

detect_public_ip() {
  local ip
  ip="$(fetch_text "https://api.ipify.org" 2>/dev/null || true)"
  if [[ -z "$ip" ]]; then
    ip="$(fetch_text "https://ipv4.icanhazip.com" 2>/dev/null || true)"
  fi
  printf '%s' "${ip//$'\n'/}"
}
