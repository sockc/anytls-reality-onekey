#!/usr/bin/env bash

open_port_if_possible() {
  local port="$1"

  if command -v ufw >/dev/null 2>&1; then
    ufw allow "${port}/tcp" >/dev/null 2>&1 || true
    ok "已尝试通过 UFW 放行 ${port}/tcp"
    return 0
  fi

  if command -v firewall-cmd >/dev/null 2>&1; then
    firewall-cmd --permanent --add-port="${port}/tcp" >/dev/null 2>&1 || true
    firewall-cmd --reload >/dev/null 2>&1 || true
    ok "已尝试通过 firewalld 放行 ${port}/tcp"
    return 0
  fi

  warn "未检测到 UFW 或 firewalld，请自行检查云防火墙/安全组。"
}
