#!/usr/bin/env bash

ensure_singbox_installed() {
  if command -v sing-box >/dev/null 2>&1; then
    ok "已检测到 sing-box: $(sing-box version | head -n 1)"
    return 0
  fi

  info "未检测到 sing-box，开始按官方方式安装。"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL https://sing-box.app/install.sh | sh
  elif command -v wget >/dev/null 2>&1; then
    wget -qO- https://sing-box.app/install.sh | sh
  else
    die "未找到 curl 或 wget，无法安装 sing-box。"
  fi

  command -v sing-box >/dev/null 2>&1 || die "sing-box 安装失败。"
  ok "sing-box 安装完成。"
}
